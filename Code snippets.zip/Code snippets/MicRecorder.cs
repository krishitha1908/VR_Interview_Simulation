using UnityEngine;
using System;

public class MicRecorder : MonoBehaviour
{
    private AudioClip clip;
    private int sampleRate = 16000;
    public Action<AudioClip> OnRecordingComplete;

    public void StartRecording(int seconds = 5)
    {
        clip = Microphone.Start(null, false, seconds, sampleRate);
        Debug.Log("🎙️ Recording started...");

    	Invoke(nameof(StopRecording), seconds);
    }

    public void StopRecording()
    {
        if (Microphone.IsRecording(null))
        {
            Microphone.End(null);
            Debug.Log("🛑 Recording stopped.");

            OnRecordingComplete?.Invoke(clip);
        }
    }
}

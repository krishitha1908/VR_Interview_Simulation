using UnityEngine;
using UnityEngine.Networking;
using System.Collections; // if your WavUtility is in a namespace called Utils
using System.IO;


public class WitAIClient : MonoBehaviour
{
    [Header("Paste your Wit.ai Server Token here")]
    public string witToken = "Bearer YBTY5TCJCC4BBGVELMACET7NLBJ53ZBS";

    public InterviewManager manager; // assign in Inspector

    public void TranscribeClip(AudioClip clip)
    {
        byte[] data = WavUtility.FromAudioClip(clip);
    	string path = Path.Combine(Application.persistentDataPath, "test.wav");
    	File.WriteAllBytes(path, data);
    	Debug.Log("🎧 Saved recording to: " + path);
        StartCoroutine(SendToWit(data));
    }

    private IEnumerator SendToWit(byte[] wav)
    {
        UnityWebRequest www = new UnityWebRequest("https://api.wit.ai/speech", "POST");
        www.uploadHandler = new UploadHandlerRaw(wav);
        www.downloadHandler = new DownloadHandlerBuffer();
        www.SetRequestHeader("Authorization", witToken);
        www.SetRequestHeader("Content-Type", "audio/wav");

        Debug.Log("Sending audio to Wit.ai...");

        yield return www.SendWebRequest();

        if (www.result == UnityWebRequest.Result.Success)
        {
            string response = www.downloadHandler.text;
            string text = ParseWitResponse(response);
            Debug.Log("Transcribed: " + text);

            manager.OnUserAnswer(text); // send to backend
        }
        else
        {
            Debug.LogError("Wit.ai error: " + www.error);
        }
    }

    private string ParseWitResponse(string json)
    {
        // Simple parser – get "_text" field from JSON
        int index = json.IndexOf("\"_text\":\"") + 8;
        int end = json.IndexOf("\"", index);
        return json.Substring(index, end - index);
    }


}

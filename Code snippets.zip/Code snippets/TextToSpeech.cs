using UnityEngine;
using System.Diagnostics;

public class TextToSpeech : MonoBehaviour
{
    public void Speak(string text)
    {
        string escapedText = text.Replace("\"", "\\\"");
        string script = $"Add-Type -AssemblyName System.Speech; " +
                        $"$speak = New-Object System.Speech.Synthesis.SpeechSynthesizer; " +
                        $"$speak.Speak(\"{escapedText}\")";

        ProcessStartInfo psi = new ProcessStartInfo();
        psi.FileName = "powershell.exe";
        psi.Arguments = $"-Command \"{script}\"";
        psi.CreateNoWindow = true;
        psi.UseShellExecute = false;

        Process.Start(psi);
    }
}

using UnityEngine;
using TMPro;

public class InterviewController : MonoBehaviour
{
    public InterviewAPI api;
    public TMP_Dropdown domainDropdown;
    public TMP_InputField experienceInput;
    public InterviewManager manager; // Reference to InterviewManager

    public void OnStartClicked()
    {
        string domain = domainDropdown.options[domainDropdown.value].text.ToLower();
        string experience = experienceInput.text;

        // Call the backend to initialize the session
        StartCoroutine(api.StartInterview(domain, experience, () =>
        {
            Debug.Log("Interview initialized");

            // Fetch the first question (which also starts voice input)
            manager.FetchQuestion();
        }));
    }
}

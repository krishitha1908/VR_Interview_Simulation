using UnityEngine;
using TMPro;

public class InterviewManager : MonoBehaviour
{
    public InterviewAPI api;
    public TextToSpeech tts;
    public MicRecorder recorder;
    public WitAIClient witClient;

    public TextMeshProUGUI questionText;
    public TextMeshProUGUI feedbackText;

    void Start()
    {
        Debug.Log("InterviewManager started");
        witClient.manager = this;
        recorder.OnRecordingComplete += witClient.TranscribeClip;

        feedbackText.gameObject.SetActive(false);
        questionText.gameObject.SetActive(false);
    }

    public void FetchQuestion()
    {
        feedbackText.gameObject.SetActive(false);
        questionText.gameObject.SetActive(true);

        StartCoroutine(api.GetQuestion((question) =>
        {
            Debug.Log("Fetched question: " + question);
            questionText.text = question;
            tts.Speak(question);

            // Automatically start listening after speaking (delay optional)
            Invoke(nameof(StartListening), 3f); // Wait ~3s before listening
        }));
    }

    public void StartListening()
    {
        recorder.StartRecording(5); // Record for 5 seconds
    }

    public void OnUserAnswer(string answer)
    {
        Debug.Log("User Answer: " + answer);
        StartCoroutine(api.EvaluateAnswer(answer, (feedback) =>
        {
            Debug.Log("Feedback: " + feedback);
            feedbackText.text = feedback;
            feedbackText.gameObject.SetActive(true);
            questionText.gameObject.SetActive(false);
            tts.Speak(feedback);
        }));
    }

    public void NextQuestion()
    {
        FetchQuestion(); // Fetches new question and starts voice again
    }
}

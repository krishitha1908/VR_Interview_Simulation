using System.Collections;
using UnityEngine;
using UnityEngine.Networking;

public class InterviewAPI : MonoBehaviour
{
    public string serverUrl = "http://192.168.61.4:5000";

    public IEnumerator StartInterview(string domain, string experience, System.Action callback)
    {
        WWWForm form = new WWWForm();
        form.AddField("domain", domain);
        form.AddField("experience", experience);

        using UnityWebRequest www = UnityWebRequest.Post($"{serverUrl}/start_interview", form);
        yield return www.SendWebRequest();

        if (www.result == UnityWebRequest.Result.Success)
        {
            Debug.Log("Interview session initialized.");
            callback?.Invoke();
        }
        else
        {
            Debug.LogError("StartInterview error: " + www.error);
        }
    }

    public IEnumerator GetQuestion(System.Action<string> callback)
    {
        using UnityWebRequest www = UnityWebRequest.PostWwwForm($"{serverUrl}/get_question", "");
        yield return www.SendWebRequest();

        if (www.result == UnityWebRequest.Result.Success)
        {
            string question = JsonUtility.FromJson<QuestionResponse>(www.downloadHandler.text).question;
            callback?.Invoke(question);
        }
        else
        {
            Debug.LogError("Question error: " + www.error);
        }
    }

    public IEnumerator EvaluateAnswer(string answer, System.Action<string> callback)
    {
        string jsonData = JsonUtility.ToJson(new AnswerRequest { answer = answer });
        var request = new UnityWebRequest($"{serverUrl}/evaluate_answer", "POST");
        byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
        request.uploadHandler = new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");

        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            string feedback = JsonUtility.FromJson<FeedbackResponse>(request.downloadHandler.text).feedback;
            callback?.Invoke(feedback);
        }
        else
        {
            Debug.LogError("Answer eval error: " + request.error);
        }
    }

    [System.Serializable] public class QuestionResponse { public string question; }
    [System.Serializable] public class FeedbackResponse { public string feedback; }
    [System.Serializable] public class AnswerRequest { public string answer; }
}

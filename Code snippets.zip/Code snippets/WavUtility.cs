using System;
using System.IO;
using UnityEngine;

public static class WavUtility
{
    public static byte[] FromAudioClip(AudioClip clip)
    {
        using (MemoryStream stream = new MemoryStream())
        {
            int hz = clip.frequency;
            int channels = clip.channels;
            float[] samples = new float[clip.samples * channels];
            clip.GetData(samples, 0);

            byte[] wavData = ConvertToPCM16(samples);

            WriteHeader(stream, hz, channels, wavData.Length);
            stream.Write(wavData, 0, wavData.Length);

            return stream.ToArray();
        }
    }

    private static byte[] ConvertToPCM16(float[] samples)
    {
        byte[] pcm = new byte[samples.Length * 2];
        int index = 0;

        foreach (var sample in samples)
        {
            short val = (short)(Mathf.Clamp(sample, -1f, 1f) * short.MaxValue);
            byte[] bytes = BitConverter.GetBytes(val);
            pcm[index++] = bytes[0];
            pcm[index++] = bytes[1];
        }

        return pcm;
    }

    private static void WriteHeader(Stream stream, int hz, int channels, int dataLength)
    {
        BinaryWriter writer = new BinaryWriter(stream);

        writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));
        writer.Write(36 + dataLength);
        writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVE"));
        writer.Write(System.Text.Encoding.ASCII.GetBytes("fmt "));
        writer.Write(16); // Subchunk1Size
        writer.Write((short)1); // AudioFormat PCM
        writer.Write((short)channels);
        writer.Write(hz);
        writer.Write(hz * channels * 2); // ByteRate
        writer.Write((short)(channels * 2)); // BlockAlign
        writer.Write((short)16); // BitsPerSample
        writer.Write(System.Text.Encoding.ASCII.GetBytes("data"));
        writer.Write(dataLength);
    }
}
